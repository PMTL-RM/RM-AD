package ncnu.com;

import android.app.Activity;

import android.os.Bundle;

import android.view.View;

import android.widget.Button;

import android.widget.TextView;

import ncnu.com.R;

public class MainActivity extends Activity {

    /** Called when the activity is first created. */

    @Override

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button button01 = (Button)findViewById(R.id.button);

        button01.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v) {

                // TODO Auto-generated method stub

                jumpToLayout02();

            }

        });

    }

    public void jumpToLayout02(){

        setContentView(R.layout.activity_main2);

        Button button02= (Button)findViewById(R.id.button);

        button02.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v) {

                // TODO Auto-generated method stub

                jumpToLayout01();

            }

        });

    }

    public void jumpToLayout01(){

        setContentView(R.layout.activity_main);

        Button button01 = (Button)findViewById(R.id.button);

        button01.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v) {

                // TODO Auto-generated method stub

                jumpToLayout02();

            }

        });

    }

}